from segunda_prenetrega import cliente
cliente1 = cliente("1,85", "venezolana", "23", "jose","C.A.B.A, palermo")       
print(cliente1.altura)
print(cliente1.edad)
print(cliente1.nacionalidad)
print(cliente1.nombre)
print(cliente1.direccion)
    
